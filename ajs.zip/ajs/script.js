(function(){
 var app = angular.module('sam',[]);
 app.controller('samcontroller',function(){
	 this.product=s;
	 console.log("script execute");
});

var s={
	name: 'Dodecahedron',
	price: 2.95,
	description: '. . .',
}
})();